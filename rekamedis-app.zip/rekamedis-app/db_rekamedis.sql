-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2024 at 05:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rekamedis`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_obat`
--

CREATE TABLE `tbl_obat` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kegunaan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_obat`
--

INSERT INTO `tbl_obat` (`id`, `nama`, `kegunaan`) VALUES
(1, 'Paracetamol', 'obat pusing'),
(2, 'Waisan', 'obat sakit gigi dan nyeri'),
(4, 'Laserin', 'Obat untuk mengatasi batuk'),
(5, 'Paramex', 'Untuk mengatasi sakit Kepala'),
(6, 'Vicks', 'untuk mengatasi hidup tersumbat'),
(7, 'Antangin', 'untuk mengatasi masuk angin'),
(8, 'Antimo', 'mengatasi mabuk perjalanan'),
(9, 'Balsem', 'Mencegah Sakit Perut'),
(10, 'Bintang ToeDjoe', 'Untuk sakit gigi'),
(11, 'Mixagrip', 'Meriang');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pasien`
--

CREATE TABLE `tbl_pasien` (
  `id` varchar(20) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `gender` enum('P','W') NOT NULL,
  `telpon` varchar(15) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_pasien`
--

INSERT INTO `tbl_pasien` (`id`, `nama`, `tgl_lahir`, `gender`, `telpon`, `alamat`) VALUES
('241226074856', 'Rossi Andini', '2004-09-22', 'W', '089622744757', 'munjul jaya'),
('241226075745', 'firda mei', '2005-05-12', 'W', '0882001949853', 'Maracang Purwakarta'),
('241226090716', 'Purwa Putra', '2000-12-31', 'P', '01928374645', 'Pasar rebo'),
('241230015810', 'Dimas Rivaldi', '2001-05-22', 'P', '082214212704', 'Subang, Cipeundeuy'),
('241230015914', 'Rizdika William W', '2002-10-12', 'P', '098765432345', 'Cibening, Bungursari'),
('241230015952', 'Fikri Ahmad Z', '2002-08-15', 'P', '08678954322', 'Cirata,Bendungan'),
('241230020046', 'Fahriza', '2003-02-20', 'P', '08745678932', 'cempaka,'),
('241230020216', 'Daffa Taufiq', '2001-05-30', 'P', '08345678987', 'Taman Pembaharuan, belakang SMP 7'),
('241230020253', 'Latif', '2002-08-13', 'P', '089758246117', 'Pondok Salam'),
('241230020347', 'Raka Putra P', '2001-01-22', 'P', '098765432678', 'Purnawarman kidul'),
('250102094446', 'Abdul', '2004-02-22', 'P', '0898765432', 'pwk');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rekamedis`
--

CREATE TABLE `tbl_rekamedis` (
  `no_rm` varchar(15) NOT NULL,
  `tgl_rm` date NOT NULL,
  `id_pasien` varchar(20) NOT NULL,
  `keluhan` text NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `diagnosa` text NOT NULL,
  `obat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_rekamedis`
--

INSERT INTO `tbl_rekamedis` (`no_rm`, `tgl_rm`, `id_pasien`, `keluhan`, `id_dokter`, `diagnosa`, `obat`) VALUES
('RM-001-020125', '2024-01-02', '241230015952', 'sakit kepala', 9, 'migrain', 'Antimo'),
('RM-001-291224', '2024-12-29', '241226074856', 'sering marah marah, lemas', 10, 'Darting', 'Paracetamol'),
('RM-001-301224', '2024-01-10', '241226075745', 'Sering merasa mual mual', 8, 'Lambung kronis', 'Balsem, Bintang ToeDjoe'),
('RM-002-020125', '2024-02-18', '241226075745', 'mencret', 8, 'sakit perut', 'Antimo'),
('RM-002-291224', '2024-10-29', '241226090716', 'sering lemas', 7, 'diabetes', 'Waisan'),
('RM-002-301224', '2024-05-15', '241230015810', 'Sering merasa susah tidur', 9, 'insomnia', 'Mixagrip'),
('RM-003-301224', '2024-03-20', '241230015914', 'sering sakit ketika lutut ditekuk', 7, 'hamstring dibagian lutut', 'Vicks'),
('RM-004-301224', '2024-08-02', '241230015952', 'sering batuk batuk', 8, 'CUACA', 'Laserin'),
('RM-005-301224', '2024-06-12', '241230020253', 'Sering lupa', 9, 'kurang minum', 'Paracetamol'),
('RM-006-301224', '2024-12-30', '241230020347', 'merasa mual ketika makan', 10, 'lambung kotor', 'Laserin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jabatan` enum('1','2','3') NOT NULL COMMENT '1=administrator,\r\n 2=petugas,\r\n 3=dokter',
  `alamat` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `username`, `fullname`, `password`, `jabatan`, `alamat`, `gambar`) VALUES
(2, 'admin', 'Administrator', '$2y$10$hFG/dVpDK9qgwQKD7pcQeeOATLegiUexUd0Op2v69Jx99hH5ABYSC', '1', 'Purwakarta', '1734976555-1731388578757.png'),
(5, 'Rosda', 'Rossi Firda', '$2y$10$3Jlnb61mVp.kPp4ieJKFnO6/PQOga0NXxkw2ODlbCPUXvjuDmJrmi', '2', 'Sadang Purwakarta', '1735118511-photo_2024-12-25_15-14-11 (2).jpg'),
(7, 'Richard Lee', 'Dr. Richard Lee', '$2y$10$L8vr3vw3FYjiLfBTmVQfEuKrT.kL95h5qY2q0I3eShOfAZsoM3FHO', '3', 'Bandung, Jawa Barat.', '1735543916-OIP.jpg'),
(8, 'Ajat Sudrajat', 'Dr. Ajat Sudrajat', '$2y$10$UmO1pQs5CRw0.gqvBmdR9uT8fMGS9EvL.WIPZuvzdB8gUtPTpt.9W', '3', 'Gg. Beringin, Samping Kampus UPI purwakarta', '1735543899-depositphotos_14779771-stock-photo-portrait-of-confident-young-doctor.jpg'),
(9, 'Melvyn', 'Dr. Melvyn', '$2y$10$owhmmBbhgL.ZqXa2PjLVJ.aiYtGzT.WJHGDWKZsPvqJ6jbymSPCBK', '3', 'Jl. Jend, Ahmad Yani, No 07, Kec. Purwakarta', '1735544042-02.jpg'),
(10, 'Eva', 'Dr. Eva', '$2y$10$NJcL7ingNcS1zvt9qRXNOOvm1NL9WtZNb0MK/prLHQYYrnWGLnctm', '3', 'Jl. Gatot Subroto', '1735829384-orang-miskin-dilarang-jadi-dokter.jpg'),
(11, 'Petugas', 'Siswanto kuntoro', '$2y$10$XxGgz2os54GD4f/JbymW5ORmOtOWlJ6JQoyXzABn/eH3Jtxzf5zFi', '2', 'pwk', 'user.png'),
(12, 'Dokter', 'Mahadewa', '$2y$10$qxHXEJqL1iuQxsInYNCM.euqHqMHoLvvJSCAIDy19jod0sWNxY2gS', '3', 'wny', 'user.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_obat`
--
ALTER TABLE `tbl_obat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pasien`
--
ALTER TABLE `tbl_pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rekamedis`
--
ALTER TABLE `tbl_rekamedis`
  ADD PRIMARY KEY (`no_rm`),
  ADD KEY `id_pasien` (`id_pasien`),
  ADD KEY `id_dokter` (`id_dokter`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_obat`
--
ALTER TABLE `tbl_obat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_rekamedis`
--
ALTER TABLE `tbl_rekamedis`
  ADD CONSTRAINT `tbl_rekamedis_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `tbl_pasien` (`id`),
  ADD CONSTRAINT `tbl_rekamedis_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `tbl_user` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
